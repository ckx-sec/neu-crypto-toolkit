import base64

def init_box(key):
    """
    S盒
    """
    s_box = list(range(256))  # 我这里没管秘钥小于256的情况，小于256应该不断重复填充即可
    j = 0
    for i in range(256):
        j = (j + s_box[i] + ord(key[i % len(key)])) % 256
        s_box[i], s_box[j] = s_box[j], s_box[i]
    # print(type(s_box)) #for_test
    return s_box

def ex_encrypt(plain, box, mode, c_mode):
    """
    利用PRGA生成秘钥流并与密文字节异或，加解密同一个算法
    """

    if mode == '2':
        while True:
            #c_mode = input("输入你的解密模式:Base64 or ordinary\n")
            if c_mode == 'Base64':
                plain = base64.b64decode(plain)
                plain = bytes.decode(plain)
                break
            elif c_mode == 'ordinary':
                plain = plain
                break

    res = []
    i = j = 0
    for s in plain:
        i = (i + 1) % 256
        j = (j + box[i]) % 256
        box[i], box[j] = box[j], box[i]
        t = (box[i] + box[j]) % 256
        k = box[t]
        res.append(chr(ord(s) ^ k))

    cipher = "".join(res)
    # print(cipher)
    if mode == '1':
        # 化成可视字符需要编码
        print("加密后的输出(没经过任何编码):")
        print(cipher)
        res1 = "加密后的输出(没经过任何编码):" + cipher + "\n"
        # base64的目的也是为了变成可见字符
        print("base64后的编码:")
        print(str(base64.b64encode(cipher.encode('utf-8')), 'utf-8'))
        res2 = "base64后的编码:" + str(base64.b64encode(cipher.encode('utf-8')), 'utf-8') + "\n"
        return res1 + res2
    if mode == '2':
        print("解密后的密文：")
        print(cipher)
        return "解密后的密文(ordinary)：" + cipher + "\n"
