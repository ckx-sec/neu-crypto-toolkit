# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'demo.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setMinimumSize(QSize(800, 600))
        MainWindow.setMaximumSize(QSize(800, 600))
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.result = QLabel(self.centralwidget)
        self.result.setObjectName(u"result")
        self.result.setGeometry(QRect(30, 290, 71, 21))
        self.result_out = QTextBrowser(self.centralwidget)
        self.result_out.setObjectName(u"result_out")
        self.result_out.setGeometry(QRect(30, 320, 731, 192))
        self.encryption = QPushButton(self.centralwidget)
        self.encryption.setObjectName(u"encryption")
        self.encryption.setGeometry(QRect(320, 250, 93, 31))
        self.decryption = QPushButton(self.centralwidget)
        self.decryption.setObjectName(u"decryption")
        self.decryption.setGeometry(QRect(630, 250, 93, 31))
        self.layoutWidget = QWidget(self.centralwidget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(20, 10, 258, 216))
        self.verticalLayout = QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.plain = QLabel(self.layoutWidget)
        self.plain.setObjectName(u"plain")

        self.verticalLayout.addWidget(self.plain)

        self.plain_in = QTextEdit(self.layoutWidget)
        self.plain_in.setObjectName(u"plain_in")

        self.verticalLayout.addWidget(self.plain_in)

        self.layoutWidget1 = QWidget(self.centralwidget)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(500, 10, 258, 216))
        self.verticalLayout_2 = QVBoxLayout(self.layoutWidget1)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.cipher = QLabel(self.layoutWidget1)
        self.cipher.setObjectName(u"cipher")

        self.verticalLayout_2.addWidget(self.cipher)

        self.cipher_in = QTextEdit(self.layoutWidget1)
        self.cipher_in.setObjectName(u"cipher_in")

        self.verticalLayout_2.addWidget(self.cipher_in)

        self.layoutWidget2 = QWidget(self.centralwidget)
        self.layoutWidget2.setObjectName(u"layoutWidget2")
        self.layoutWidget2.setGeometry(QRect(30, 250, 212, 26))
        self.horizontalLayout = QHBoxLayout(self.layoutWidget2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.key = QLabel(self.layoutWidget2)
        self.key.setObjectName(u"key")

        self.horizontalLayout.addWidget(self.key)

        self.key_in = QLineEdit(self.layoutWidget2)
        self.key_in.setObjectName(u"key_in")

        self.horizontalLayout.addWidget(self.key_in)

        self.decryption_bsse64 = QPushButton(self.centralwidget)
        self.decryption_bsse64.setObjectName(u"decryption_bsse64")
        self.decryption_bsse64.setGeometry(QRect(450, 250, 151, 31))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"RC4", None))
        self.result.setText(QCoreApplication.translate("MainWindow", u"result:", None))
        self.encryption.setText(QCoreApplication.translate("MainWindow", u"Encryption", None))
        self.decryption.setText(QCoreApplication.translate("MainWindow", u"Decryption", None))
        self.plain.setText(QCoreApplication.translate("MainWindow", u"Plaintext:", None))
        self.cipher.setText(QCoreApplication.translate("MainWindow", u"Ciphertext:", None))
        self.key.setText(QCoreApplication.translate("MainWindow", u"key:", None))
        self.decryption_bsse64.setText(QCoreApplication.translate("MainWindow", u"Decryption_bsse64", None))
    # retranslateUi

