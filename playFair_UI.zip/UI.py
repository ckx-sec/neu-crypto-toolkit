# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'UI.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 520)
        MainWindow.setMinimumSize(QSize(800, 520))
        MainWindow.setMaximumSize(QSize(800, 520))
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.layoutWidget = QWidget(self.centralwidget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(60, 10, 258, 216))
        self.verticalLayout = QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.plain = QLabel(self.layoutWidget)
        self.plain.setObjectName(u"plain")

        self.verticalLayout.addWidget(self.plain)

        self.plain_in = QTextEdit(self.layoutWidget)
        self.plain_in.setObjectName(u"plain_in")

        self.verticalLayout.addWidget(self.plain_in)

        self.layoutWidget1 = QWidget(self.centralwidget)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(500, 10, 258, 216))
        self.verticalLayout_2 = QVBoxLayout(self.layoutWidget1)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.cipher = QLabel(self.layoutWidget1)
        self.cipher.setObjectName(u"cipher")

        self.verticalLayout_2.addWidget(self.cipher)

        self.cipher_in = QTextEdit(self.layoutWidget1)
        self.cipher_in.setObjectName(u"cipher_in")

        self.verticalLayout_2.addWidget(self.cipher_in)

        self.layoutWidget2 = QWidget(self.centralwidget)
        self.layoutWidget2.setObjectName(u"layoutWidget2")
        self.layoutWidget2.setGeometry(QRect(60, 260, 212, 26))
        self.horizontalLayout = QHBoxLayout(self.layoutWidget2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.key = QLabel(self.layoutWidget2)
        self.key.setObjectName(u"key")

        self.horizontalLayout.addWidget(self.key)

        self.key_in = QLineEdit(self.layoutWidget2)
        self.key_in.setObjectName(u"key_in")

        self.horizontalLayout.addWidget(self.key_in)

        self.layoutWidget3 = QWidget(self.centralwidget)
        self.layoutWidget3.setObjectName(u"layoutWidget3")
        self.layoutWidget3.setGeometry(QRect(60, 290, 298, 135))
        self.gridLayout = QGridLayout(self.layoutWidget3)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.encryption = QPushButton(self.layoutWidget3)
        self.encryption.setObjectName(u"encryption")

        self.gridLayout.addWidget(self.encryption, 0, 1, 1, 1)

        self.decryption = QPushButton(self.layoutWidget3)
        self.decryption.setObjectName(u"decryption")

        self.gridLayout.addWidget(self.decryption, 0, 2, 1, 1)

        self.label = QLabel(self.layoutWidget3)
        self.label.setObjectName(u"label")

        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.layoutWidget4 = QWidget(self.centralwidget)
        self.layoutWidget4.setObjectName(u"layoutWidget4")
        self.layoutWidget4.setGeometry(QRect(430, 260, 331, 161))
        self.verticalLayout_3 = QVBoxLayout(self.layoutWidget4)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.result = QLabel(self.layoutWidget4)
        self.result.setObjectName(u"result")

        self.verticalLayout_3.addWidget(self.result)

        self.result_out = QTextBrowser(self.layoutWidget4)
        self.result_out.setObjectName(u"result_out")

        self.verticalLayout_3.addWidget(self.result_out)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Polygram Substitution", None))
        self.plain.setText(QCoreApplication.translate("MainWindow", u"Plaintext:", None))
        self.cipher.setText(QCoreApplication.translate("MainWindow", u"Ciphertext:", None))
        self.key.setText(QCoreApplication.translate("MainWindow", u"key:", None))
        self.encryption.setText(QCoreApplication.translate("MainWindow", u"Encryption", None))
        self.decryption.setText(QCoreApplication.translate("MainWindow", u"Decryption", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"playfair:", None))
        self.result.setText(QCoreApplication.translate("MainWindow", u"result:", None))
    # retranslateUi

