# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'UI.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1017, 776)
        MainWindow.setMinimumSize(QSize(1017, 776))
        MainWindow.setMaximumSize(QSize(1017, 776))
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(50, 10, 72, 31))
        self.ip_input = QLineEdit(self.centralwidget)
        self.ip_input.setObjectName(u"ip_input")
        self.ip_input.setGeometry(QRect(100, 10, 221, 31))
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(478, 10, 51, 31))
        self.port_input = QLineEdit(self.centralwidget)
        self.port_input.setObjectName(u"port_input")
        self.port_input.setGeometry(QRect(530, 10, 131, 31))
        self.connect_btn = QPushButton(self.centralwidget)
        self.connect_btn.setObjectName(u"connect_btn")
        self.connect_btn.setGeometry(QRect(840, 10, 93, 31))
        self.layoutWidget = QWidget(self.centralwidget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(650, 70, 258, 229))
        self.verticalLayout_4 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.priv_key_gen = QPushButton(self.layoutWidget)
        self.priv_key_gen.setObjectName(u"priv_key_gen")

        self.verticalLayout_4.addWidget(self.priv_key_gen)

        self.privkey_res = QTextBrowser(self.layoutWidget)
        self.privkey_res.setObjectName(u"privkey_res")

        self.verticalLayout_4.addWidget(self.privkey_res)

        self.enc_and_send = QPushButton(self.centralwidget)
        self.enc_and_send.setObjectName(u"enc_and_send")
        self.enc_and_send.setGeometry(QRect(800, 310, 201, 71))
        self.label_4 = QLabel(self.centralwidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(30, 140, 101, 51))
        self.label_4.setStyleSheet(u"font: 16pt \"Arial\";")
        self.label_5 = QLabel(self.centralwidget)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(40, 490, 121, 51))
        self.label_5.setStyleSheet(u"font: 16pt \"Arial\";")
        self.layoutWidget_2 = QWidget(self.centralwidget)
        self.layoutWidget_2.setObjectName(u"layoutWidget_2")
        self.layoutWidget_2.setGeometry(QRect(660, 410, 258, 216))
        self.verticalLayout_6 = QVBoxLayout(self.layoutWidget_2)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.label_7 = QLabel(self.layoutWidget_2)
        self.label_7.setObjectName(u"label_7")

        self.verticalLayout_6.addWidget(self.label_7)

        self.gened_peivkey = QTextBrowser(self.layoutWidget_2)
        self.gened_peivkey.setObjectName(u"gened_peivkey")

        self.verticalLayout_6.addWidget(self.gened_peivkey)

        self.layoutWidget_3 = QWidget(self.centralwidget)
        self.layoutWidget_3.setObjectName(u"layoutWidget_3")
        self.layoutWidget_3.setGeometry(QRect(570, 650, 425, 89))
        self.horizontalLayout = QHBoxLayout(self.layoutWidget_3)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.label_9 = QLabel(self.layoutWidget_3)
        self.label_9.setObjectName(u"label_9")

        self.horizontalLayout.addWidget(self.label_9)

        self.deced_plt = QTextBrowser(self.layoutWidget_3)
        self.deced_plt.setObjectName(u"deced_plt")

        self.horizontalLayout.addWidget(self.deced_plt)

        self.label_10 = QLabel(self.centralwidget)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(0, 50, 1071, 20))
        self.label_11 = QLabel(self.centralwidget)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(-10, 380, 1031, 20))
        self.send_file = QPushButton(self.centralwidget)
        self.send_file.setObjectName(u"send_file")
        self.send_file.setGeometry(QRect(100, 310, 201, 71))
        self.layoutWidget1 = QWidget(self.centralwidget)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(220, 70, 258, 229))
        self.verticalLayout_3 = QVBoxLayout(self.layoutWidget1)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.pub_key_gen = QPushButton(self.layoutWidget1)
        self.pub_key_gen.setObjectName(u"pub_key_gen")

        self.verticalLayout_3.addWidget(self.pub_key_gen)

        self.geged_pub_key = QTextBrowser(self.layoutWidget1)
        self.geged_pub_key.setObjectName(u"geged_pub_key")
        self.geged_pub_key.setMaximumSize(QSize(16777215, 16777215))

        self.verticalLayout_3.addWidget(self.geged_pub_key)

        self.layoutWidget2 = QWidget(self.centralwidget)
        self.layoutWidget2.setObjectName(u"layoutWidget2")
        self.layoutWidget2.setGeometry(QRect(450, 310, 353, 71))
        self.horizontalLayout_4 = QHBoxLayout(self.layoutWidget2)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.label_3 = QLabel(self.layoutWidget2)
        self.label_3.setObjectName(u"label_3")

        self.horizontalLayout_4.addWidget(self.label_3)

        self.plaintext_in = QTextEdit(self.layoutWidget2)
        self.plaintext_in.setObjectName(u"plaintext_in")

        self.horizontalLayout_4.addWidget(self.plaintext_in)

        self.layoutWidget3 = QWidget(self.centralwidget)
        self.layoutWidget3.setObjectName(u"layoutWidget3")
        self.layoutWidget3.setGeometry(QRect(220, 410, 258, 216))
        self.verticalLayout_5 = QVBoxLayout(self.layoutWidget3)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.label_6 = QLabel(self.layoutWidget3)
        self.label_6.setObjectName(u"label_6")

        self.verticalLayout_5.addWidget(self.label_6)

        self.reded_pubkey = QTextBrowser(self.layoutWidget3)
        self.reded_pubkey.setObjectName(u"reded_pubkey")

        self.verticalLayout_5.addWidget(self.reded_pubkey)

        self.layoutWidget4 = QWidget(self.centralwidget)
        self.layoutWidget4.setObjectName(u"layoutWidget4")
        self.layoutWidget4.setGeometry(QRect(80, 650, 425, 89))
        self.horizontalLayout_3 = QHBoxLayout(self.layoutWidget4)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.label_8 = QLabel(self.layoutWidget4)
        self.label_8.setObjectName(u"label_8")

        self.horizontalLayout_3.addWidget(self.label_8)

        self.reced_cip = QTextBrowser(self.layoutWidget4)
        self.reced_cip.setObjectName(u"reced_cip")

        self.horizontalLayout_3.addWidget(self.reced_cip)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1017, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"IP:", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"port:", None))
        self.connect_btn.setText(QCoreApplication.translate("MainWindow", u"connect", None))
        self.priv_key_gen.setText(QCoreApplication.translate("MainWindow", u"gengrate private key:", None))
        self.enc_and_send.setText(QCoreApplication.translate("MainWindow", u"encryption and send", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Sender:", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Receiver:", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"generated private key:", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"decriped plain text:", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"------------------------------------------------------------------------------------------------------------------------------------", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"-------------------------------------------------------------------------------------------------------------------------------------------------", None))
        self.send_file.setText(QCoreApplication.translate("MainWindow", u"send file", None))
        self.pub_key_gen.setText(QCoreApplication.translate("MainWindow", u"gengrate public key:", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"plain text:", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"reciveed public key:", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"recived cipher text:", None))
    # retranslateUi

