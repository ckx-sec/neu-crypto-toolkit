import os
import sys
import random
import threading
from PyQt5.QtCore import pyqtSignal
from PySide2 import QtGui, QtWidgets, QtCore
from PySide2.QtWidgets import QApplication, QMainWindow
from UI import Ui_MainWindow
import socket
import commands
from DH import min_g, multi_mod
import random
from Crypto.Util.number import *
from RC4 import encrypt, init_box, decrypt
from Crypto.Util.number import long_to_bytes, bytes_to_long
import base64
from client1 import socket_client
from server1 import deal_data, socket_service
import time


# 主窗体类
class MainWindow(QMainWindow, Ui_MainWindow):
    serversocket = socket.socket(
        socket.AF_INET, socket.SOCK_STREAM)
    # 获取本地主机名
    host = socket.gethostname()
    host = '0.0.0.0'
    port = 9999
    # 绑定端口号
    serversocket.bind((host, port))
    # 设置最大连接数，超过后排队
    serversocket.listen(5)

    connected_host = socket.gethostname()
    connected_port = 6666
    p = 0
    g = 0
    a = 0
    A = 0
    B = 0
    b = 0
    keyA = 0
    keyB = 0
    key = 0
    plaintext = ''
    ciphertext = ''
    count = 0

    def filedel(self):
        socket_service()

    def lisandrep(self):
        while True:
            # 建立客户端连接
            clientsocket, addr = self.serversocket.accept()
            print("连接地址: %s" % str(addr))
            msg = 'connection succeed!' + "\r\n"
            data = clientsocket.recv(2048)
            listre = data.split(b',')
            print(listre)
            if listre[0] == b'hello':
                clientsocket.send(msg.encode('utf-8'))
            if listre[0] == b'pk':
                self.p = int(listre[1].decode())
                self.g = int(listre[2].decode())
                self.keyB = int(listre[3].decode())
                self.key = pow(self.keyB, self.A, self.p)
                self.privkey_res.append("b = %d" % self.keyB)
                toshow = "p: " + str(self.p) + "\n" + "g: " + str(self.g) + "\n"
                self.reded_pubkey.append(toshow)
                toshow = "A: " + str(self.A) + "\n" + "key: " + str(self.key)
                self.gened_peivkey.append(toshow)
                clientsocket.send(str(self.keyA).encode())
            if listre[0] == b'cit':
                self.ciphertext = listre[1]
                self.reced_cip.append(str(listre[1]))
                self.plaintext = decrypt(self.ciphertext, str(self.key)).decode('utf-8')
                print(self.plaintext)
                self.deced_plt.append(self.plaintext)
            if listre[0] == b'fil':
                time.sleep(1)
                with open('tosend.txt', 'rb',) as f:
                    reccip = decrypt(f.read(), str(self.key)).decode('utf-8')
                    print(reccip)
                with open("tosend_decoede%d.txt" % self.count, 'w', encoding='utf-8') as f:
                    f.write(reccip)
                    f.close()
                self.count += 1
            clientsocket.close()
        s.close()

    def connectNow(self):
        # 创建 socket 对象
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 获取本地主机名
        host = socket.gethostname()
        host = self.ip_input.text()
        print(host)
        # 设置端口号
        port = 6666
        port = int(self.port_input.text())
        print(port)
        # 连接服务，指定主机和端口
        s.connect((host, port))
        s.sendall("hello,".encode())
        msg = s.recv(2048)
        s.close()
        print(msg.decode('utf-8'))


    def gen_pubk(self):
        self.p = getPrime(512)
        print("生成的512比特位大质数p为%d" % self.p)
        self.geged_pub_key.append("生成的512比特位大质数p为%d" % self.p)
        self.geged_pub_key.append("\n")
        self.g = min_g(self.p)
        self.geged_pub_key.append("最小原根为%d" % self.g)
        print("最小原根为%d" % self.g)
        self.geged_pub_key.append("\n")
        self.A = random.randint(0, self.p - 1)

    def gen_a(self):


        # 创建 socket 对象
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 获取本地主机名
        host = socket.gethostname()
        host = self.ip_input.text()
        print(host)
        # 设置端口号
        port = 6666
        port = int(self.port_input.text())
        # 连接服务，指定主机和端口
        s.connect((host, port))
        # 接收小于 1024 字节的数据

        self.keyA = pow(self.g, self.A, self.p)

        self.privkey_res.append("a = %d" % self.A)
        self.privkey_res.append("\n")
        self.privkey_res.append("等待另一端返回b值......\n")
        to_send = 'pk,' + str(self.p) + ',' + str(self.g) + ',' + str(self.keyA)
        print(to_send)
        s.sendall(to_send.encode("utf8"))
        print(to_send)
        msg = s.recv(2048)
        s.close()
        print(msg.decode('utf-8'))
        self.keyB = int(msg.decode())
        self.privkey_res.append('b = ' + str(self.keyB))

    def send_cip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 获取本地主机名
        # host = socket.gethostname()
        host = self.ip_input.text()
        print(host)
        # 设置端口号
        # port = 6666
        port = int(self.port_input.text())
        # 连接服务，指定主机和端口
        s.connect((host, port))
        send_cip = self.plaintext_in.toPlainText().encode()

        send_cip = encrypt(send_cip, str(self.key))
        with open('../tosend.txt', 'wb+') as f:
            #reccip = decrypt(send_cip, str(self.key))
            f.write(send_cip)
        tosendciptext = b'cit,' + send_cip
        s.sendall(tosendciptext)
        # s.sendall(tosendciptext)

    def sendfile(self):
        socket_client()
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 获取本地主机名
        # host = socket.gethostname()
        host = self.ip_input.text()
        print(host)
        # 设置端口号
        # port = 6666
        port = int(self.port_input.text())
        # 连接服务，指定主机和端口
        s.connect((host, port))
        tosendciptext = b'fil,'
        s.sendall(tosendciptext)

    def th1(self):
        # 定义字符
        self.hello = ["Hallo Welt", "Hei maailma", "Hola Mundo", "Привет мир", "Hello world"]
        self.connect_btn.clicked.connect(self.connectNow)
        self.pub_key_gen.clicked.connect(self.gen_pubk)
        self.priv_key_gen.clicked.connect(self.gen_a)
        self.enc_and_send.clicked.connect(self.send_cip)
        self.send_file.clicked.connect(self.sendfile)

    def __init__(self):

        super(MainWindow, self).__init__()
        self.setupUi(self)

        uisurface = threading.Thread(target=self.th1, args=())
        uisurface.start()  # 前端线程

        liser = threading.Thread(target=self.lisandrep, args=())
        liser.start()  # 监听端口

        fllese = threading.Thread(target=self.filedel, args=())
        fllese.start()




if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
