# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'UI.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 520)
        MainWindow.setMinimumSize(QSize(800, 520))
        MainWindow.setMaximumSize(QSize(800, 520))
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.layoutWidget = QWidget(self.centralwidget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(60, 10, 258, 216))
        self.verticalLayout = QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.plain = QLabel(self.layoutWidget)
        self.plain.setObjectName(u"plain")

        self.verticalLayout.addWidget(self.plain)

        self.plain_in = QTextEdit(self.layoutWidget)
        self.plain_in.setObjectName(u"plain_in")

        self.verticalLayout.addWidget(self.plain_in)

        self.layoutWidget1 = QWidget(self.centralwidget)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(500, 10, 258, 216))
        self.verticalLayout_2 = QVBoxLayout(self.layoutWidget1)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.cipher = QLabel(self.layoutWidget1)
        self.cipher.setObjectName(u"cipher")

        self.verticalLayout_2.addWidget(self.cipher)

        self.cipher_in = QTextEdit(self.layoutWidget1)
        self.cipher_in.setObjectName(u"cipher_in")

        self.verticalLayout_2.addWidget(self.cipher_in)

        self.layoutWidget2 = QWidget(self.centralwidget)
        self.layoutWidget2.setObjectName(u"layoutWidget2")
        self.layoutWidget2.setGeometry(QRect(60, 260, 212, 26))
        self.horizontalLayout = QHBoxLayout(self.layoutWidget2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.key = QLabel(self.layoutWidget2)
        self.key.setObjectName(u"key")

        self.horizontalLayout.addWidget(self.key)

        self.key_in = QLineEdit(self.layoutWidget2)
        self.key_in.setObjectName(u"key_in")

        self.horizontalLayout.addWidget(self.key_in)

        self.widget = QWidget(self.centralwidget)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(60, 290, 298, 135))
        self.gridLayout = QGridLayout(self.widget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(self.widget)
        self.label.setObjectName(u"label")

        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.encryption = QPushButton(self.widget)
        self.encryption.setObjectName(u"encryption")

        self.gridLayout.addWidget(self.encryption, 0, 1, 1, 1)

        self.decryption = QPushButton(self.widget)
        self.decryption.setObjectName(u"decryption")

        self.gridLayout.addWidget(self.decryption, 0, 2, 1, 1)

        self.label_2 = QLabel(self.widget)
        self.label_2.setObjectName(u"label_2")

        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)

        self.Keyword_Encp = QPushButton(self.widget)
        self.Keyword_Encp.setObjectName(u"Keyword_Encp")

        self.gridLayout.addWidget(self.Keyword_Encp, 1, 1, 1, 1)

        self.ketword_decp = QPushButton(self.widget)
        self.ketword_decp.setObjectName(u"ketword_decp")

        self.gridLayout.addWidget(self.ketword_decp, 1, 2, 1, 1)

        self.label_3 = QLabel(self.widget)
        self.label_3.setObjectName(u"label_3")

        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)

        self.affine_Encp = QPushButton(self.widget)
        self.affine_Encp.setObjectName(u"affine_Encp")

        self.gridLayout.addWidget(self.affine_Encp, 2, 1, 1, 1)

        self.affine_decp = QPushButton(self.widget)
        self.affine_decp.setObjectName(u"affine_decp")

        self.gridLayout.addWidget(self.affine_decp, 2, 2, 1, 1)

        self.label_4 = QLabel(self.widget)
        self.label_4.setObjectName(u"label_4")

        self.gridLayout.addWidget(self.label_4, 3, 0, 1, 1)

        self.mulliteral_Encp = QPushButton(self.widget)
        self.mulliteral_Encp.setObjectName(u"mulliteral_Encp")

        self.gridLayout.addWidget(self.mulliteral_Encp, 3, 1, 1, 1)

        self.mulliteral_decp = QPushButton(self.widget)
        self.mulliteral_decp.setObjectName(u"mulliteral_decp")

        self.gridLayout.addWidget(self.mulliteral_decp, 3, 2, 1, 1)

        self.widget1 = QWidget(self.centralwidget)
        self.widget1.setObjectName(u"widget1")
        self.widget1.setGeometry(QRect(430, 260, 331, 161))
        self.verticalLayout_3 = QVBoxLayout(self.widget1)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.result = QLabel(self.widget1)
        self.result.setObjectName(u"result")

        self.verticalLayout_3.addWidget(self.result)

        self.result_out = QTextBrowser(self.widget1)
        self.result_out.setObjectName(u"result_out")

        self.verticalLayout_3.addWidget(self.result_out)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u" Monoalphabetic Substitution Cipher ", None))
        self.plain.setText(QCoreApplication.translate("MainWindow", u"Plaintext:", None))
        self.cipher.setText(QCoreApplication.translate("MainWindow", u"Ciphertext:", None))
        self.key.setText(QCoreApplication.translate("MainWindow", u"key:", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"caesar:", None))
        self.encryption.setText(QCoreApplication.translate("MainWindow", u"Encryption", None))
        self.decryption.setText(QCoreApplication.translate("MainWindow", u"Decryption", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"keyword:", None))
        self.Keyword_Encp.setText(QCoreApplication.translate("MainWindow", u"Encryption", None))
        self.ketword_decp.setText(QCoreApplication.translate("MainWindow", u"Decryrtion", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"affine:", None))
        self.affine_Encp.setText(QCoreApplication.translate("MainWindow", u"Encryption", None))
        self.affine_decp.setText(QCoreApplication.translate("MainWindow", u"Decryrtion", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"multliteral:", None))
        self.mulliteral_Encp.setText(QCoreApplication.translate("MainWindow", u"Encryption", None))
        self.mulliteral_decp.setText(QCoreApplication.translate("MainWindow", u"Decryrtion", None))
        self.result.setText(QCoreApplication.translate("MainWindow", u"result:", None))
    # retranslateUi

