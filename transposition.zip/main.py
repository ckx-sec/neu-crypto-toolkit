import sys
import random
from PySide2 import QtGui, QtWidgets, QtCore
from PySide2.QtWidgets import QApplication, QMainWindow
from UI import Ui_MainWindow
import transposition


# 主窗体类
class MainWindow(QMainWindow, Ui_MainWindow):
    def fun_perdecp(self):
        cip = self.cipher_in.toPlainText()
        print(cip)
        key = self.key_in.text()
        print(key)
        rul = key.split(',')
        rul = list(map(int, rul))
        cip_res = transposition.Permutation.decode(cip, rul)
        self.result_out.append(cip_res)

    def fun_perencp(self):
        plt = self.plain_in.toPlainText()
        print(plt)
        key = self.key_in.text()
        print(key)
        rul = key.split(',')
        rul = list(map(int, rul))
        cip_res = transposition.Permutation.encode(plt, rul)
        self.result_out.append(cip_res)

    def fun_col_perencp(self):
        plt = self.plain_in.toPlainText()
        print(plt)
        key = self.key_in.text()
        print(key)
        cip_res = transposition.ColumnPermutation.encode(plt, key)
        self.result_out.append(cip_res)

    def fun_col_perdecp(self):
        cip = self.cipher_in.toPlainText()
        print(cip)
        key = self.key_in.text()
        print(key)
        cip_res = transposition.ColumnPermutation.decode(cip, key)
        self.result_out.append(cip_res)

    def fun_dou_trsencp(self):
        plt = self.plain_in.toPlainText()
        print(plt)
        key = self.key_in.text()
        print(key)
        hkey = key.split(',')
        cip_res = transposition.ColumnPermutation.double_encode(plt, hkey[0], hkey[1])
        self.result_out.append(cip_res)

    def fun_dou_trsdecp(self):
        cip = self.cipher_in.toPlainText()
        print(cip)
        key = self.key_in.text()
        print(key)
        hkey = key.split(',')
        cip_res = transposition.ColumnPermutation.double_decode(cip, hkey[0], hkey[1])
        self.result_out.append(cip_res)

    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        # 定义字符
        self.hello = ["Hallo Welt", "Hei maailma", "Hola Mundo", "Привет мир", "Hello world"]
        self.encryption.clicked.connect(self.fun_perencp)
        self.decryption.clicked.connect(self.fun_perdecp)
        self.coluper_encp.clicked.connect(self.fun_col_perencp)
        self.coluper_decp.clicked.connect(self.fun_col_perdecp)
        self.doubtrs_encp.clicked.connect(self.fun_dou_trsencp)
        self.doubtrs_decp.clicked.connect(self.fun_dou_trsdecp)
        # 添加槽链接
        # self.pushButton.clicked.connect(self.magic)
        '''

        关于槽链接，在PySide中调用的格式是：
        发送者.信号.connect(槽函数)

        Qt是面向对象的程序设计，只有某个动作才会触发某个效果。使用槽链接的方式，可以实现复杂的操作。
        使用槽链接时，一定要在官方文档查找发送者有哪些信号，例如pushButton有clicked信号可以激活槽链接。
        '''

    def magic(self):
        # 随机选取
        self.label.setText(random.choice(self.hello))


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())